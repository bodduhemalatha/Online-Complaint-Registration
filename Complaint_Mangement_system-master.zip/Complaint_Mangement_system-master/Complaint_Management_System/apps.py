from django.apps import AppConfig


class ComplaintManagementSystemConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Complaint_Management_System'
    
